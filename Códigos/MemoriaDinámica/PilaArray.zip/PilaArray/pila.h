#include <stdbool.h>
#ifndef PILA_H // Evita la inclusión múltiple del archivo de encabezado
#define PILA_H

enum Tipo
{
    PLASTICO,
    METAL,
    MADERA
};

//typedef struct Node Node; //Mismo que lo de abajo
typedef struct Node
{
    int color;
    float capacidad;
    enum Tipo material;

} Node;

typedef struct Pila *PtrPila;
struct Pila
{
    Node *top;
    unsigned size;
    unsigned capacity;
} Pila;


/**
 * @brief Inicializa la pila
 * @param ptrPila Puntero a la pila 
 * @param capacity Capacidad de la pila 
 */
void init(PtrPila ptrPila, unsigned capacity);

/**
 * @brief Añadimos un elemento a la pila
 * @param ptrptrNode  Puntero a la pila (que es un puntero a un nodo)
 * @param element  Elemento a añadir
 */
void push(PtrPila ptrPila, struct Node element);


/**
 * @brief Devuelve el elemento en la cima de la pila
 * @param pila  Puntero a la pila 
 * @return Puntero al elemento en la cima de la pila 
 */
Node top(PtrPila ptrPila);

/**
 * @brief Elimina el elemento en la cima de la pila
 * @param ptrptrNode Puntero a la pila (que es un puntero a un nodo) de la que se quiere eliminar el elemento en la cima
 * @return true se puede eliminar, false en caso contrario
 */
bool pop(PtrPila ptrPila);

/**
 * @brief Comprueba si la pila está vacía
 * @param pila  Pila a comprobar
 * @return true si la pila está vacía, false en caso contrario
 */
bool isEmpty(PtrPila ptrPila);

/**
 * @brief Devuelve el número de elementos en la pila
 * @param pila  Pila de la que se quiere obtener el número de elementos
 * @return Número de elementos en la pila
 */
int size(PtrPila ptrPila);

/**
 * @brief Elimina todos los elementos de la pila
 * @param ptrptrNode Puntero a la pila (que es un puntero a un nodo) que se quiere vaciar
 */
void clear(PtrPila ptrPila);

/**
 * @brief Muestra los elementos de la pila 
 * @param pila Pila a mostrar
 */
void show(PtrPila ptrPila);

#endif
