#include "pila.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
int main(void)
{
    PtrPila pila = (PtrPila) malloc(sizeof(struct Pila));
    init(pila, 1);
    Node n1 = {1, 2.5, PLASTICO};
    Node n2 = {2, 3.5, METAL};
    Node n3 = {3, 4.5, MADERA};
    push(pila, n1);
    push(pila, n2);
    push(pila, n3);

    printf("---------------------------------\n");
    show(pila);
    assert(top(pila).color == 3);
    assert(top(pila).capacidad == 4.5);
    assert(top(pila).material == MADERA);
    pop(pila);
    assert(top(pila).color == 2);
    assert(top(pila).capacidad == 3.5);
    assert(top(pila).material == METAL);

    printf("---------------------------------\n");
    show(pila);
    pop(pila);
    assert(top(pila).color == 1);
    assert(top(pila).capacidad == 2.5);
    assert(top(pila).material == PLASTICO);

    printf("---------------------------------\n");
    show(pila);
    pop(pila);
    assert(isEmpty(pila));

    
    return 0;
}
